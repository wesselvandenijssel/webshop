# glu-base-api

Search values from database with a API. Change the values yourself in the querystring. The values to call the database:

# create:

http://localhost/database/api/product/create.php?category_id=1&naam=1&beschrijving=1&prijs=1

# update:

http://localhost/database/api/product/update.php?id=1&category_id=1&naam=Cola&beschrijving=Lekkahh&prijs=2.00

# delete

http://localhost/database/api/product/delete.php?id=1&category_id=1&naam=Cola&beschrijving=Lekkahhh&prijs=2.00

# readOne

http://localhost/database/api/product/read_one.php?id=4

# readAll

http://localhost/database/api/product/read_all.php
