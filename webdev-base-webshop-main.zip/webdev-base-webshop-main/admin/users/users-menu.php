
<ul>
<li><a href="../index_loggedin.php">Admin-hoofdmenu</a></li>
</ul>

Admin-usersmenu:
<ul>
<li><a href="index.php">overzicht van gebruikers</a></li>
<li><a href="add_user.php">gebruiker toevoegen</a></li>
</ul>