<?php
    include('core/header.php');
?>
Overzicht van producten met ProductNaam, ProductPrijs, ProductAfbeelding en ProductCategorie
<?php
    include('core/footer.php');
?>