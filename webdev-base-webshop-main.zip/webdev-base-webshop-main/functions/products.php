<?php
function getRandomHomeProducts(){
    global $con;
    
}
?>