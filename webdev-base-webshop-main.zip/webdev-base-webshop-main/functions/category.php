<?php
function getCategory(){
    
}
?>